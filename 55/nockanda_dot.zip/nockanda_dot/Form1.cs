﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nockanda_dot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        Bitmap bt;
        private void button1_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                bt = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = bt;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            for(int i = 0; i < bt.Height; i++)
            {
                richTextBox1.Text += "B";
                for (int j = 0; j < bt.Width; j++)
                {
                    if (j % 8 == 0 && j != 0)
                    {
                        richTextBox1.Text += ", B";
                    }

                    if (bt.GetPixel(j, i).R == 0)
                    {
                        richTextBox1.Text += "1";
                    }
                    else
                    {
                        richTextBox1.Text += "0";
                    }
                    
                }
                richTextBox1.Text += ",\n";
            }
        }
    }
}
