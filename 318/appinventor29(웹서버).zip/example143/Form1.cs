﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;

namespace example143
{
    public partial class Form1 : Form
    {
        Dictionary<string, string> name = new Dictionary<string, string>();

        bool server_run = true;
        HttpListener listener;
        Thread t;
        public Form1()
        {
            InitializeComponent();

            name.Add("05512345678", "녹칸다분식");
            name.Add("05512123434","녹칸다찜질");
            name.Add("05549493232","녹칸다스시");
            name.Add("05510102020", "녹칸다국밥");
            name.Add("05598765432", "녹칸다레스토랑");
        }

        public void ThreadProc()
        {
            
            while (server_run)
            {
                listener = new HttpListener();

                listener.Prefixes.Add("http://*:60000/");

                listener.Start();

                richTextBox1.Text += "Listening...\n";

                // Note: The GetContext method blocks while waiting for a request.
                HttpListenerContext context = listener.GetContext();
                HttpListenerRequest request = context.Request;
                HttpListenerResponse response = context.Response;

                

                if (request.RawUrl == "/favicon.ico")
                {
                    richTextBox1.Text += "아이콘 무시했음\n";
                    //대충 response
                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes("OK");
                    // Get a response stream and write the response to it.
                    response.ContentLength64 = buffer.Length;
                    System.IO.Stream output = response.OutputStream;
                    output.Write(buffer, 0, buffer.Length);
                    // You must close the output stream.
                    output.Close();
                    listener.Stop();
                }
                else
                {
                    richTextBox1.Text += request.RawUrl + "\n";
                    //요청하는 디바이스별로 처리를 다르게 하겠다!
                    // Windows Android

                    string responseString = "";
                    string number1 = "";
                    string number2 = "";
                    if (request.UserAgent.IndexOf("Windows") != -1)
                    {
                        richTextBox1.Text += "당신은 웹브라우저입니다!\n";
                        //웹브라우저
                        //   /?number1=test1&number2=test2
                        string data = request.RawUrl.Replace("/?", "");
                        string[] keyvalue = data.Split('&');
                        //keyvalue[0]
                        //keyvalue[1]
                        number1 = keyvalue[0].Split('=')[1];
                        number2 = keyvalue[1].Split('=')[1];

                        if (name.ContainsKey(number2))
                        {
                            //업체번호가 딕셔너리에 존재하는경우
                            responseString = "<html><head><meta charset=\"UTF-8\"></head><body>" + name[number2] + "업소 방문 체크가 성공적으로 등록되었습니다!" + "</body></html>\n";
                        }
                        else
                        {
                            //존재하지 않는경우
                            responseString = "<html><head><meta charset=\"UTF-8\"></head><body>잘못된입력입니다!</body></html>\n";
                        }
                    }
                    else if (request.UserAgent.IndexOf("Android") != -1)
                    {
                        richTextBox1.Text += "당신은 스마트폰입니다!\n";
                        //앱인벤터
                        // /01011112222/05512345678
                        string[] data = request.RawUrl.Split('/');
                        number1 = data[1];
                        number2 = data[2];

                        if (name.ContainsKey(number2))
                        {
                            //업체번호가 딕셔너리에 존재하는경우
                            responseString = name[number2] + "업소 방문 체크가 성공적으로 등록되었습니다!\n";
                        }
                        else
                        {
                            //존재하지 않는경우
                            responseString = "잘못된 입력입니다!\n";
                        }
                    }

                    
                    string mytime = DateTime.Now.ToString();

                    //requset를 처리하는 부분
                    //request
                    //richTextBox1.Text += request.RawUrl + "\n";
                    //  /01011112222/05512345678
                    //  [0]~
                    //  [1]01011112222
                    //  [2]05512345678
                    
                    // 스마트폰 주인 전화번호 : data[1]
                    // 방문한 업체의 전화번호 : data[2]
                    

                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = number1;
                    lvi.SubItems.Add(number2);
                    lvi.SubItems.Add(name[number2]);
                    lvi.SubItems.Add(mytime);
                    listView1.Items.Add(lvi);


                    
                    

                    // Obtain a response object.

                    // Construct a response.

                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                    // Get a response stream and write the response to it.
                    response.ContentLength64 = buffer.Length;
                    System.IO.Stream output = response.OutputStream;
                    output.Write(buffer, 0, buffer.Length);
                    // You must close the output stream.
                    output.Close();
                    listener.Stop();
                    
                }


                richTextBox1.Text += "DONE...\n";
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string myip = ip.ToString();
                    label1.Text = myip;
                }
            }
            
            server_run = true;

            t = new Thread(new ThreadStart(ThreadProc));
            t.Start();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (t != null)
            {
                server_run = false;

                if (listener.IsListening)
                {
                    //현재 클라이언트 기다리는 상태
                    listener.Stop();
                }

                if (t.IsAlive)
                {
                    //스레드가 돌아가고 있는 상태
                    t.Abort();
                }
            }
        }
    }
}
