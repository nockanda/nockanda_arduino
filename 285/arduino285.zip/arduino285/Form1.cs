﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using MySql.Data.MySqlClient;

namespace arduino285
{
    public partial class Form1 : Form
    {
        string Conn = "Server=localhost;Database=arduino285;Uid=root;Pwd=qwer1234;";
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            client.Subscribe(new string[] { "nockanda/cds1", "nockanda/cds2", "nockanda/cds3" }, new byte[] { 0,0,0 });
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/cds1")
            {
                label1.Text = ReceivedMessage;
            }else if (e.Topic == "nockanda/cds2")
            {
                label2.Text = ReceivedMessage;
            }else if (e.Topic == "nockanda/cds3")
            {
                label3.Text = ReceivedMessage;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                DataSet ds = new DataSet();
                string sql = "select * from sensor where d_num=1 order by date desc limit 20";
                MySqlDataAdapter adpt = new MySqlDataAdapter(sql, conn);
                adpt.Fill(ds, "sensor");

                richTextBox1.Text = "";
                for(int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    richTextBox1.Text += ds.Tables[0].Rows[i]["d_num"].ToString() +"\t";
                    richTextBox1.Text += ds.Tables[0].Rows[i]["cds"].ToString() + "\t";
                    richTextBox1.Text += ds.Tables[0].Rows[i]["date"].ToString() + "\n";
                }
            }
        }
    }
}
