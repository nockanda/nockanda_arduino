﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft.Json.Linq;

namespace arduino340
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //구독등록
            string[] mytopic = { "nockanda/station/data" };
            byte[] qos = {0 };
            client.Subscribe(mytopic, qos);
        }
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            //ReceivedMessage (JSON)
            //JSON데이터를 파싱
            try
            {
                JObject wheather_data = JObject.Parse(ReceivedMessage);
                //wheather_data["wind_direct"].ToString();
                //wheather_data["wind_speed"].ToString();
                //wheather_data["rain_amout"].ToString();
                //wheather_data["humi"].ToString();
                //wheather_data["temp"].ToString();
                label1.Text = "풍향: "+ wheather_data["wind_direct"].ToString() + "˚";
                label2.Text = "풍속: "+ wheather_data["wind_speed"].ToString() + " m/s";
                label3.Text = "우량: "+ wheather_data["rain_amout"].ToString() + " mm";
                label4.Text = "기온: "+ wheather_data["temp"].ToString() + " 'C";
                label5.Text = "습도: "+ wheather_data["humi"].ToString() + "%";


                //리스트뷰에 집어넣기
                ListViewItem lvi = new ListViewItem();
                lvi.Text = DateTime.Now.ToString();
                lvi.SubItems.Add(wheather_data["wind_direct"].ToString());
                lvi.SubItems.Add(wheather_data["wind_speed"].ToString());
                lvi.SubItems.Add(wheather_data["rain_amout"].ToString());
                lvi.SubItems.Add(wheather_data["temp"].ToString());
                lvi.SubItems.Add(wheather_data["humi"].ToString());

                listView1.Items.Add(lvi);

                //풍향 게이지로 표현하기
                aGauge1.Value = (int)float.Parse(wheather_data["wind_direct"].ToString());


                //차트 그리기
                float[] data = new float[5];
                data[0] = float.Parse(wheather_data["wind_direct"].ToString());
                data[1] = float.Parse(wheather_data["wind_speed"].ToString());
                data[2] = float.Parse(wheather_data["rain_amout"].ToString());
                data[3] = float.Parse(wheather_data["temp"].ToString());
                data[4] = float.Parse(wheather_data["humi"].ToString());
                

                for (int i = 0; i < 5; i++)
                {
                    //일단 추가를 한다
                    chart1.Series[i].Points.AddY(data[i]);

                    //윈도우 사이즈가 20이다
                    //데이터 총 갯수가 20보다 크다면 제일 먼저 들어온 데이터를 뺸다
                    if (chart1.Series[i].Points.Count > 20)
                    {
                        chart1.Series[i].Points.RemoveAt(0);
                    }
                }
            }
            catch
            {

            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MQTT 연결 종료
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (client.IsConnected)
            {
                client.Publish("nockanda/station/rain", Encoding.UTF8.GetBytes("0"), 0, true);
            }
        }
    }
}
