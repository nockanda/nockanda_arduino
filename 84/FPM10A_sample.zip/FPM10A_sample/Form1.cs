﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FPM10A_sample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //finger print reference
        //https://github.com/hanifizzudinrahman/Module-Fingerprint-DY50-FPM10A/blob/master/Example/%5B%20EXAMPLE%20Serial%20Monitor%20%5D/%5B%20OUTPUT%20SERIAL%20%5D%20DY50_FPM10A_ShowImageTemplete_ShowTemplete.cpp
        private void button1_Click(object sender, EventArgs e)
        {
            string filepath = "";
            if (radioButton1.Checked)
            {
                filepath = "./sample.txt";
            }
            if (radioButton2.Checked)
            {
                filepath = "./sample2.txt";
            }
            if (radioButton3.Checked)
            {
                filepath = "./sample3.txt";
            }
            FileStream fs = new FileStream(filepath, FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            Bitmap bt = new Bitmap(128, 288);
            Graphics g = Graphics.FromImage(bt);
            g.Clear(Color.Black);

            int linenumber = 0;
            while (!sr.EndOfStream)
            {
                string input = sr.ReadLine();
                int index1 = input.IndexOf("= {EF 01 FF FF FF FF 02 00 82");
                index1 = index1 + 30;
                input = input.Remove(0, index1);
                input = input.Remove(input.Length - 9, 9);
                //string -> 헥사
                string[] pixel = input.Split(' ');
                //string2byte(pixel[i]);
                for (int i = 0; i < pixel.Length; i++)
                {
                    byte value = string2byte(pixel[i]);
                    Color c = Color.FromArgb(value, value, value);
                    Brush b = new SolidBrush(c);
                    g.FillRectangle(b, i, linenumber, 1, 1);
                }

                linenumber++;
            }

            g.Dispose();
            sr.Close();
            sr.Dispose();
            fs.Close();
            fs.Dispose();
            pictureBox1.Image = bt;
        }
        byte string2byte(string input)
        {
            byte output = 0;
            if(input[0] >= '0' && input[0] <= '9')
            {
                output = (byte)(input[0] - '0');
                output = (byte)(output << 4);
            }
            else
            {
                output = (byte)(input[0] - 55);
                output = (byte)(output << 4);
            }

            if (input[1] >= '0' && input[1] <= '9')
            {
                output += (byte)(input[0] - '0');
            }
            else
            {
                output += (byte)(input[0] - 55);
            }

            return output;
        }
    }
}
