var connection = new WebSocket('ws://192.168.0.11:81/', ['arduino']);
  connection.onopen = function () {
  };
  connection.onerror = function (error) {
     console.log(error);
  };
  connection.onmessage = function (e) {
     var box = document.getElementById('content-text');
     box.innerText = e.data; 
     console.log(e.data);
  };