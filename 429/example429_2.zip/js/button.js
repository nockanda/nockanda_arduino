var b1 = document.getElementById("mybtn1");
var b2 = document.getElementById("mybtn2");


b1.addEventListener("click", function(){
	var box = document.getElementById("content-text");
	box.innerText = "버튼1번 눌려짐!";
});
b2.addEventListener("click", function(){
	var box = document.getElementById("content-text");
	box.innerText = "버튼2번 눌려짐!";
});
