var connection = new WebSocket('ws://192.168.0.11:81/', ['arduino']);
  connection.onopen = function () {
  };
  connection.onerror = function (error) {
     console.log(error);
  };
  connection.onmessage = function (e) {
     var box1 = document.getElementById('content-text1');
     var box2 = document.getElementById('content-text2');
     var box3 = document.getElementById('content-text3');
     var data = JSON.parse(e.data);
     box1.innerText = "1번센서="+data.s1; 
     box2.innerText = "2번센서="+data.s2; 
     box3.innerText = "3번센서="+data.s3; 
     
     console.log(e.data);
  };