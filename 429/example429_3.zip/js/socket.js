var connection = new WebSocket('ws://192.168.0.11:81/', ['arduino']);
  connection.onopen = function () {
  };
  connection.onerror = function (error) {
     console.log('WebSocket Error ', error);
  };
  connection.onmessage = function (e) {
     console.log('Server: ', e.data);
  };var connection = new WebSocket('ws://192.168.0.11:81/', ['arduino']);
  connection.onopen = function () {
  };
  connection.onerror = function (error) {
     console.log(error);
  };
  connection.onmessage = function (e) {
     console.log(e.data);
  };