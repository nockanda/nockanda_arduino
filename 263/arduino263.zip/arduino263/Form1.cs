﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace arduino263
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MQTT 브로커와 연결하는 부분
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            client.Subscribe(new string[] { "nockanda/notice", "nockanda/door", "nockanda/lock" }, new byte[] { 0,0,0 });
        }

        //MQTT이벤트 핸들러
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            //DO SOMETHING..!
            if(e.Topic == "nockanda/notice")
            {
                label2.Text = ReceivedMessage;
            }else if(e.Topic == "nockanda/door")
            {
                label4.Text = ReceivedMessage;
            }
            else if(e.Topic == "nockanda/lock")
            {
                label6.Text = ReceivedMessage;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/login", Encoding.UTF8.GetBytes(textBox1.Text), 0, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/set", Encoding.UTF8.GetBytes("0"), 0, true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            client.Publish("nockanda/change", Encoding.UTF8.GetBytes(textBox2.Text + ","+textBox3.Text), 0, true);
        }
    }
}
