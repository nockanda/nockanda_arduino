﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace arduino332_2
{
    public partial class Form1 : Form
    {
        MqttClient client;
        string clientId;

        public Form1()
        {
            InitializeComponent();
        }

        double[] temps = { 0, 0, 0 };
        double[] humis = { 0, 0, 0 };

        private void Form1_Load(object sender, EventArgs e)
        {
            string BrokerAddress = "broker.mqtt-dashboard.com";
            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

            //C#에서 구독하고자하는 topic을 지정
            string[] topic = { "nockanda/node32", "nockanda/node118", "nockanda/node200" };
            byte[] qos = { 0, 0, 0 };

            client.Subscribe(topic, qos);

            //그래프를 그리는 timer를 on
            timer1.Start();
        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);
            //e.Topic
            //DO SOMETHING..!

            //ReceivedMessage JSON 파싱
            JObject json = JObject.Parse(ReceivedMessage);

            string node_id = json["device"].ToString();
            string humi = json["humi"].ToString();
            string temp = json["temp"].ToString();

            //라벨
            if(node_id == "32")
            {
                //label1.Text = "온도:" + temp + "'C";
                //label2.Text = "습도:" + humi + "%";

                humis[0] = double.Parse(humi);
                temps[0] = double.Parse(temp);

                aGauge1.Value = (float)temps[0];
                aGauge2.Value = (float)humis[0];

            }
            else if(node_id == "118")
            {
                //label3.Text = "온도:" + temp + "'C";
                //label4.Text = "습도:" + humi + "%";

                humis[1] = double.Parse(humi);
                temps[1] = double.Parse(temp);
                aGauge3.Value = (float)temps[1];
                aGauge4.Value = (float)humis[1];
            }
            else if(node_id == "200")
            {
                //label5.Text = "온도:" + temp + "'C";
                //label6.Text = "습도:" + humi + "%";

                humis[2] = double.Parse(humi);
                temps[2] = double.Parse(temp);
                aGauge5.Value = (float)temps[2];
                aGauge6.Value = (float)humis[2];
            }

            //리스트뷰
            ListViewItem lvi = new ListViewItem();
            lvi.Text = node_id;
            lvi.SubItems.Add(humi);
            lvi.SubItems.Add(temp);

            listView1.Items.Add(lvi);

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            client.Disconnect();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //5초마다 게이트웨이에서 측정한 값을 가지고 그래프를 그린다

            //온도그래프
            //데이터를 집어넣는다
            chart1.Series[0].Points.AddY(temps[0]);
            chart1.Series[1].Points.AddY(temps[1]);
            chart1.Series[2].Points.AddY(temps[2]);

            chart2.Series[0].Points.AddY(humis[0]);
            chart2.Series[1].Points.AddY(humis[1]);
            chart2.Series[2].Points.AddY(humis[2]);

            //윈도우 사이즈를 지정 = 20
            for (int i = 0; i < 3; i++)
            {
                if (chart1.Series[i].Points.Count > 20)
                {
                    chart1.Series[i].Points.RemoveAt(0);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                if (chart2.Series[i].Points.Count > 20)
                {
                    chart2.Series[i].Points.RemoveAt(0);
                }
            }
        }
    }
}
