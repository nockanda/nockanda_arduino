﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arduino332_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            serialPort1.PortName = textBox1.Text;
            serialPort1.Open();
            
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //println()
            int node_id = serialPort1.ReadByte();
            string rawdata = serialPort1.ReadLine();//온도, 습도

            rawdata = rawdata.Replace("\r", "");
            string[] data = rawdata.Split(',');
            //data[0] : 온도
            //data[1] : 습도

            if (data.Length == 2)
            {
                //label에 노드별로 데이터 집어넣기
                if(node_id == 0xAA)
                {
                    //1번노드
                    label1.Text = "온도:" + data[0] + "'C";
                    label2.Text = "습도:" + data[1] + "%";
                    label7.Text = "시간:" + DateTime.Now.ToString();

                    if (check_number(data[0]))
                    {

                        double temp = double.Parse(data[0]);
                        if (temp > 50)
                        {
                            groupBox1.BackColor = Color.Red;
                        }
                        else
                        {
                            groupBox1.BackColor = Color.White;
                        }
                    }
                }
                else if(node_id == 0xBB)
                {
                    //2번노드
                    label3.Text = "온도:" + data[0] + "'C";
                    label4.Text = "습도:" + data[1] + "%";
                    label8.Text = "시간:" + DateTime.Now.ToString();

                    if (check_number(data[0]))
                    {

                        double temp = double.Parse(data[0]);
                        if (temp > 50)
                        {
                            groupBox2.BackColor = Color.Red;
                        }
                        else
                        {
                            groupBox2.BackColor = Color.White;
                        }
                    }
                }
                else if(node_id == 0xCC)
                {
                    //3번노드
                    label5.Text = "온도:" + data[0] + "'C";
                    label6.Text = "습도:" + data[1] + "%";
                    label9.Text = "시간:" + DateTime.Now.ToString();

                    if (check_number(data[0]))
                    {

                        double temp = double.Parse(data[0]);
                        if (temp > 50)
                        {
                            groupBox3.BackColor = Color.Red;
                        }
                        else
                        {
                            groupBox3.BackColor = Color.White;
                        }
                    }
                }

                //리스트뷰에 데이터 집어넣기!
                ListViewItem lvi = new ListViewItem();
                lvi.Text = node_id.ToString();
                lvi.SubItems.Add(data[0]);
                lvi.SubItems.Add(data[1]);

                listView1.Items.Add(lvi);
            }
        }

        bool check_number(string input)
        {
            bool output = true;

            input = input.Replace(".", "");
            for (int i = 0; i < input.Length; i++)
            {
                //0~9 사이가 아니거나

                if (input[i] < '0') output = false;

                else if (input[i] > '9') output = false;

            }

            return output;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
        }
    }
}
